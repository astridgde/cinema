import { Injectable } from '@angular/core';
import { User } from '../interfaces/user.interface';
import { BehaviorSubject, Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root' // Asegúrate de que el servicio esté disponible en toda la aplicación
})
export class AutenticacionService {
  private usersKey = 'registeredUsers';
  private userAuth = 'userAuth';
  private users: User[] = [];
  private userLoginSubject = new BehaviorSubject<User | undefined>(undefined);

  constructor(private http: HttpClient) {
    this.loadLocalStorageUsers();
    this.loadLocalStorageUserLogin();
  }

  get userLogin$() {
    return this.userLoginSubject.asObservable();
  }

  registerUser(user: User): void {
    this.users.push(user);
    this.saveLocalStorage();
  }

  private saveLocalStorage() {
    localStorage.setItem(this.usersKey, JSON.stringify(this.users));
  }

  private loadLocalStorageUsers() {
    const storedUsers = localStorage.getItem(this.usersKey);
    if (storedUsers) {
      this.users = JSON.parse(storedUsers);
    }
  }

  private loadLocalStorageUserLogin() {
    const storedUser = localStorage.getItem(this.userAuth);
    if (storedUser) {
      this.userLoginSubject.next(JSON.parse(storedUser));
    }
  }

  loginUser(username: string, password: string): boolean {
    const user = this.users.find(u => u.username === username && u.password === password);
    if (!user) return false;
    this.userLoginSubject.next(user);
    return true;
  }

  logoutUser(): void {
    this.userLoginSubject.next(undefined);
    localStorage.removeItem(this.userAuth);
  }

  //Conectar con la BD 
  private readonly apiUrl = 'http://localhost:3000/api/v1'

  register(user: User) : Observable<any> {
    return this.http.post(`${this.apiUrl}/usuario/register`, user);
  }

  login(nombre_usuario: string, password: string): Observable<any> {
    return this.http.post(`${this.apiUrl}/usuario/login`, {nombre_usuario, password});
  }

  registerPersona(persona: any): Observable<any> {
    return this.http.post(`${this.apiUrl}/persona`, persona);
  }
}
