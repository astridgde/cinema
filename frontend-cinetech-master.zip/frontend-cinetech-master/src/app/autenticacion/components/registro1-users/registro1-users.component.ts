import { Component } from '@angular/core';
import { User } from '../../interfaces/user.interface';
import { Router } from '@angular/router';

@Component({
  selector: 'app-registro1-users',
  templateUrl: './registro1-users.component.html',
  styleUrl: './registro1-users.component.css'

})
export class Registro1UsersComponent {
  
  user:User={
    firstName: '',
    lastName:'',
    documentType: '',
    documentNumber: '',
    rol: 'cliente',
  }
  constructor(private router: Router) {}

  proceedToNextStep() {
    const tempUser: Partial<User> = {
      firstName: this.user.firstName,
      lastName: this.user.lastName,
      documentType: this.user.documentType,
      documentNumber: this.user.documentNumber,
      rol: this.user.rol
    };
    localStorage.setItem('tempUser', JSON.stringify(tempUser));
    this.router.navigate(['/autenticacion/aut/registrar2']);
  }
}