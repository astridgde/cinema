import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { AutenticacionService } from '../../services/Autenticacion.service';

@Component({
  selector: 'app-mi-perfil',
  templateUrl: './mi-perfil.component.html',
})
export class MiPerfilComponent implements OnInit {
  perfilForm: FormGroup;

  constructor(
    private fb: FormBuilder,
    private autenticacionService: AutenticacionService
  ) {
    this.perfilForm = this.fb.group({
      nombre: [''],
      apellido: [''],
      tipo_documento: [''],
      numero_documento: [''],
      email: [''],
      celular: [''],
      fecha_nacimiento: ['']
    });
  }

  ngOnInit(): void {
    const savedProfile = localStorage.getItem('userProfile');
    if (savedProfile) {
      this.perfilForm.setValue(JSON.parse(savedProfile));
    } else {
      this.autenticacionService.userLogin$.subscribe(user => {
        if (user) {
          this.perfilForm.patchValue({
            nombre: user.firstName,
            apellido: user.lastName,
            tipo_documento: user.documentType,
            numero_documento: user.documentNumber,
            email: user.email,
            celular: user.phoneNumber,
            fecha_nacimiento: user.birthDate
          });
        }
      });
    }
  }

  onSubmit(): void {
    if (this.perfilForm.valid) {
      localStorage.setItem('userProfile', JSON.stringify(this.perfilForm.value));
      console.log('Datos guardados:', this.perfilForm.value);
    }
  }
}