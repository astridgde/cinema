import { Component } from '@angular/core';
import { User, UserLogin } from '../../interfaces/user.interface';
import { AutenticacionService } from '../../services/Autenticacion.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-inicio-sesion',
  templateUrl: './inicio-sesion.component.html',

})
export class InicioSesionComponent {

  userLogin:User={
    username:'',
    password:'',
  }

  usuarioLogin: UserLogin = {
    nombre_usuario: '',
    password: ''
  }
  nombre_usuario: string = '';
  password: string = '';


  constructor(private autenticacionService: AutenticacionService, private router:Router){}

  sendLogin(){
  const valLogin = this.autenticacionService.loginUser(this.userLogin.username!, this.userLogin.password!)
  if (valLogin === true) this.router.navigate(['/home'])  

  }

  onLogin(){
    this.autenticacionService.login(this.nombre_usuario, this.password).subscribe(
      (data) => {
        console.log('Login exitoso',data);
        localStorage.setItem('acces_token', data.access_token);
        alert('Login exitoso');
        this.router.navigate(['/home'])
      },
      (error) => {
        console.log('Error en el login', error);
        alert('Credenciales incorrectas');
      }
    )
  }
}