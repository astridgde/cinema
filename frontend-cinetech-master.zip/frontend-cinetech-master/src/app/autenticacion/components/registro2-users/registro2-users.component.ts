import { Component } from '@angular/core';
import { User, Users } from '../../interfaces/user.interface';
import { AutenticacionService } from '../../services/Autenticacion.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-registro2-users',
  templateUrl: './registro2-users.component.html',
  styleUrl: './registro2-users.component.css'

})
export class Registro2UsersComponent {
  
  user: Users = {
    nombre_usuario: '',
    password: '',
    nombres: '',
    apellidos: '',
    correo: '',
    tipo_documento: '',
    num_documento: '',
    telefono: '',
    fecha_nacimiento: '',
  };
  
  constructor(private autenticacionService: AutenticacionService, private router: Router) {}

  
  /* register() {
    const tempUser = JSON.parse(localStorage.getItem('tempUser') || '{}');
    const user: User = {
      firstName: this.user.firstName,
      lastName: this.user.lastName,
      documentType: this.user.documentType,
      documentNumber: this.user.documentNumber,
      rol: this.user.rol,
      email: this.user.email,
      username: this.user.username,
      password: this.user.password,
      phoneNumber: this.user.phoneNumber,
      birthDate: this.user.birthDate
    };

    this.autenticacionService.registerUser(user);

    localStorage.removeItem('tempUser');

    console.log('Registro completo');
    this.router.navigate(['/autenticacion/aut/inicio-sesion']);
  } */
allowOnlyLetters(event: KeyboardEvent): void {
  const charCode = event.key.charCodeAt(0);
  // Permite letras (mayúsculas y minúsculas), espacios y backspace
  if (!((charCode >= 65 && charCode <= 90) || (charCode >= 97 && charCode <= 122) || charCode === 32)) {
    event.preventDefault();
  }
}
/* validateDocumentNumber(event: any): void {
  const input = event.target;
  input.value = input.value.replace(/[^0-9]/g, '').slice(0, 8); // Elimina caracteres no numéricos y limita a 8 dígitos.
  this.user.documentNumber = input.value; // Actualiza el modelo con el valor limpio.
}
validatePhoneNumber(event: any): void {
  const input = event.target;
  // Elimina caracteres no numéricos y limita a 9 dígitos
  input.value = input.value.replace(/[^0-9]/g, '').slice(0, 9); 
  this.user.phoneNumber = input.value; // Actualiza el modelo con el valor limpio
} */

  /* onRegister(event: Event) {
    event.preventDefault();
    this.autenticacionService.register(this.user).subscribe(
      (data) => {
        console.log('Registron exitoso', data);
        alert('Registro exitoso');
      },
      (error) => {
        console.error('Error al registar', error);
        alert('Error al registar')
      }
    )
  } */

   /*  onRegister(event: Event) {
      event.preventDefault();
    
      // Si `id_persona` no está definido, es un nuevo registro
      if (!this.user.id_persona) {
        this.autenticacionService.registerPersona(this.user.persona).subscribe({
          next: (persona) => {
            console.log('Persona registrada:', persona);
            this.user.id_persona = persona.id; // Asocia el ID de la persona al usuario
            this.registerUser(); // Procede a registrar el usuario
          },
          error: (err) => {
            console.error('Error al registrar persona:', err);
            alert('Error al registrar persona');
          },
        });
      } else {
        this.registerUser(); // Si `id_persona` ya existe, solo registra el usuario
      }
    } */
    
    registerUser() {
      this.autenticacionService.register(this.user).subscribe({
        next: (data) => {
          console.log('Usuario registrado exitosamente:', data);
          alert('Registro exitoso');
          this.router.navigate(['/autenticacion/aut/inicio-sesion']);
        },
        error: (err) => {
          console.error('Error al registrar usuario:', err);
          alert('Error al registrar usuario');
        },
      });
    }
    


}