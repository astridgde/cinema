import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AutenticacionRoutingModule } from './autenticacion-routing.module';
import { AutenticacionComponent } from './autenticacion.component';
import { InicioSesionComponent } from './components/inicio-sesion/inicio-sesion.component';
import { Registro1UsersComponent } from './components/registro1-users/registro1-users.component';
import { Registro2UsersComponent } from './components/registro2-users/registro2-users.component';
import { MiPerfilComponent } from './components/mi-perfil/mi-perfil.component';
import { RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';


@NgModule({
  declarations: [
    AutenticacionComponent,
    InicioSesionComponent,
    Registro1UsersComponent,
    Registro2UsersComponent,
    MiPerfilComponent
  ],
  imports: [
    CommonModule,
    AutenticacionRoutingModule,
    RouterModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule
  ],
  exports: [
    AutenticacionRoutingModule,
    AutenticacionComponent,
    InicioSesionComponent,
    Registro1UsersComponent,
    Registro2UsersComponent,
    MiPerfilComponent
  ]
})
export class AutenticacionModule { }
