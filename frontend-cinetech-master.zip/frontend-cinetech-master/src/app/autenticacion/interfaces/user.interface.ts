export interface Users {
  _id?: string;
  nombre_usuario: string;
  password: string;
  rol?: string;
  nombres: string;
  apellidos: string;
  correo: string;
  tipo_documento: string;
  num_documento: string;
  telefono: string;
  fecha_nacimiento: string;
}

export interface UserLogin{
  nombre_usuario: string;
  password: string;
}


export interface User {
    firstName?: string;
    lastName?: string;
    documentType?: string;
    documentNumber?: string;
    email?: string;
    username?: string;
    password?: string;
    phoneNumber?: string;
    birthDate?: string;
    rol?: string;
  }
