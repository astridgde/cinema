import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AutenticacionComponent } from './autenticacion.component';
import { Registro1UsersComponent } from './components/registro1-users/registro1-users.component';
import { Registro2UsersComponent } from './components/registro2-users/registro2-users.component';
import { InicioSesionComponent } from './components/inicio-sesion/inicio-sesion.component';
import { MiPerfilComponent } from './components/mi-perfil/mi-perfil.component';

const routes: Routes = [
  { path: '', component: AutenticacionComponent },
  { path: 'aut/registrar1', component: Registro1UsersComponent},
  { path: 'aut/registrar2', component: Registro2UsersComponent},
  { path: 'aut/inicio-sesion', component: InicioSesionComponent},
  { path: 'aut/mi-perfil', component: MiPerfilComponent},
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AutenticacionRoutingModule { }
