import { Component, OnInit } from '@angular/core';
import { CarteleraService } from '../services/Cartelera.service';
import { Router } from '@angular/router';
import { Funcion, Pelicula } from '../interfaces/interface';

@Component({
  selector: 'app-detalle-compra',
  templateUrl: './detalle-compra.component.html',
  styleUrls: ['./detalle-compra.component.css']
})
export class DetalleCompraComponent implements OnInit {
  compra: any = {}; // Inicializa el objeto compra
  total: number = 0; // Variable para almacenar el total
  funciones: Funcion[] = []; 
  peliculas: Pelicula[] = [];
  
  constructor(private peliculaService: CarteleraService, private router: Router) {}

  ngOnInit() {
    this.compra = this.peliculaService.getCompra();
    if (!this.compra || !this.compra.pelicula) {
      console.error('No se pudo cargar la compra.');
      return;
    }
    // Asigna una imagen por defecto si no hay imagen en la película
    this.compra.pelicula.imagen = this.compra.pelicula.imagen || 'https://example.com/default-image.jpg';
    this.compra.cantidad = this.compra.cantidad || 1;
    this.actualizarTotal();
  }
  


calcularTotal(): number {
  return (this.compra.cantidad || 1) * (this.compra.precio || 0); // Calcula el total correctamente
}

  // Actualiza el total según el precio y cantidad
  actualizarTotal() {
    this.total = this.calcularTotal();
  }


  // Método para aumentar la cantidad
  increaseQuantity() {
    this.compra.cantidad++;
    this.actualizarTotal();
  }

  // Decrementa la cantidad y actualiza el total
  decreaseQuantity() {
    if (this.compra.cantidad > 1) {
      this.compra.cantidad--;
      this.actualizarTotal();
    }
  }

  // Método para procesar el pago
  pagar() {
    console.log('Procesando pago:', this.compra);
    this.peliculaService.setCompra(this.compra); 
    this.router.navigate(['/cartelera/formapago']);
  }

  // Método para manejar el error de carga de imagen
  onImageError(event: Event) {
    const defaultImage = 'https://example.com/default-image.jpg';
    (event.target as HTMLImageElement).src = defaultImage;
  }
  
}
