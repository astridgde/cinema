import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { CarteleraRoutingModule } from './cartelera-routing.module';
import { CarteleraComponent } from './cartelera.component';

import { AdmCarteleraComponent } from './components/adm-cartelera/adm-cartelera.component';
import { AdmFuncionComponent } from './components/adm-cartelera/adm-funcion/adm-funcion.component';
import { AdmPeliculaComponent } from './components/adm-cartelera/adm-pelicula/adm-pelicula.component';
import { AgregarFuncionComponent } from './components/adm-cartelera/adm-funcion/agregar-funcion/agregar-funcion.component';
import { AgregarPeliculaComponent } from './components/adm-cartelera/adm-pelicula/agregar-pelicula/agregar-pelicula.component';
import { EditarFuncionComponent } from './components/adm-cartelera/adm-funcion/editar-funcion/editar-funcion.component';
import { EditarPeliculaComponent } from './components/adm-cartelera/adm-pelicula/editar-pelicula/editar-pelicula.component';
import { CarteleraSemanalComponent } from './components/cartelera-semanal/cartelera-semanal.component';
import { DetalleCompraComponent } from './detalle-compra/detalle-compra.component';
import { FormsModule } from '@angular/forms';
import { BoletaComponent } from './pages/formapago/boleta/boleta.component';
import { FormapagoComponent } from './pages/formapago/formapago.component';
import { HttpClientModule } from '@angular/common/http';


@NgModule({
  declarations: [
    CarteleraComponent,
    AdmCarteleraComponent,
    AdmFuncionComponent,
    AdmPeliculaComponent,
    AgregarFuncionComponent,
    AgregarPeliculaComponent,
    EditarFuncionComponent,
    EditarPeliculaComponent,
    CarteleraSemanalComponent,
    DetalleCompraComponent,
    BoletaComponent,
    FormapagoComponent,
    

  ],
  imports: [
    CommonModule,
    CarteleraRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  exports: [
    CarteleraRoutingModule,
    CarteleraComponent,
    AdmCarteleraComponent,
    AdmFuncionComponent,
    AdmPeliculaComponent,
    AgregarFuncionComponent,
    AgregarPeliculaComponent,
    EditarFuncionComponent,
    EditarPeliculaComponent,
    CarteleraSemanalComponent,
    FormsModule,
    DetalleCompraComponent]
})
export class CarteleraModule { }
