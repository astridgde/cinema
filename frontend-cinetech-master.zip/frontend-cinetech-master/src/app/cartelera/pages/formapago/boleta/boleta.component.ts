import { Component, OnInit } from '@angular/core';
import { CarteleraService } from '../../../services/Cartelera.service';
import { AutenticacionService } from '../../../../autenticacion/services/Autenticacion.service';
import { User } from '../../../../autenticacion/interfaces/user.interface';

@Component({
  selector: 'app-boleta',
  templateUrl: './boleta.component.html',
  styleUrls: ['./boleta.component.css']
})
export class BoletaComponent implements OnInit {
  compra: any;
  user : User | undefined;
  constructor(
    private peliculaService: CarteleraService,
    private autenticacionService: AutenticacionService
  ) {}

  ngOnInit() {
    this.compra = this.peliculaService.getCompra();

    this.autenticacionService.userLogin$.subscribe(user => {
      this.user = user;

  });
  }
  calcularTotal(): number {
    return (this.compra.cantidad || 1) * (this.compra.precio || 0); // Calcula el total correctamente
  }
}
