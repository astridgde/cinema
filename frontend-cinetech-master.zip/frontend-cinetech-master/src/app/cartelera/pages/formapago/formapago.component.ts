import { Component, OnInit } from '@angular/core';
import { CarteleraService } from '../../services/Cartelera.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-formapago',
  templateUrl: './formapago.component.html',
  styleUrls: ['./formapago.component.css']
})
export class FormapagoComponent implements OnInit {

  compra: any;
  paymentMethod: string = '';
  cardNumber: string = '';
  cardType: string = '';
  expiryMonth: string = '';
  expiryYear: string = '';
  cvv: string = '';
  documentType: string = '';
  documentNumber: string = '';

  constructor(private peliculaService: CarteleraService, private router: Router) {}

  ngOnInit() {
    this.compra = this.peliculaService.getCompra();
  }

  onChangePaymentMethod(method: string) {
    this.paymentMethod = method;
  }

  pagar() {
    if (!this.paymentMethod) {
      alert('Por favor, selecciona un método de pago.');
      return;
    }
  
    if (this.paymentMethod === 'tarjeta' && (!this.cardNumber || !this.cardType || !this.expiryMonth || !this.expiryYear || !this.cvv)) {
      alert('Por favor, completa todos los campos de la tarjeta.');
      return;
    }
  
    // Guardar los detalles de la compra en el servicio
    const compraConDetalles = {
      ...this.compra,
      paymentMethod: this.paymentMethod,
      cardNumber: this.cardNumber,
      cardType: this.cardType,
      expiryMonth: this.expiryMonth,
      expiryYear: this.expiryYear,
      cvv: this.cvv,
      documentType: this.documentType,
      documentNumber: this.documentNumber
    };
  
    this.peliculaService.setCompra(compraConDetalles);
  
   
    this.router.navigate(['/cartelera/boleta']);
  }
  calcularTotal(): number {
    return (this.compra.cantidad || 1) * (this.compra.precio || 0); 
}
onImageError(event: Event) {
  const imgElement = event.target as HTMLImageElement;
  imgElement.src = 'https://via.placeholder.com/150'; // URL de la imagen por defecto
}

}
