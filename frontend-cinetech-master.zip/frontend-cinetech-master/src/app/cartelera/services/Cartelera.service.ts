import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Funcion, Pelicula } from '../interfaces/interface';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class CarteleraService {
  private peliculasKey = 'peliculas';
  private funcionesKey = 'funciones';
  private comprasKey = 'compras';
  private compraKey = 'compra';
  private peliculas: any[] = [];
  private funciones: any[] = [];
  private compras: any[] = [];
  private compra: any = {};

  constructor(private http : HttpClient) {
    this.loadData();
  }

  // Cargar datos desde localStorage
  private loadData() {
    const peliculasData = localStorage.getItem(this.peliculasKey);
    const funcionesData = localStorage.getItem(this.funcionesKey);
    const comprasData = localStorage.getItem(this.comprasKey);
    const compraData = localStorage.getItem(this.compraKey);

    this.peliculas = peliculasData ? JSON.parse(peliculasData) : this.defaultPeliculas();
    this.funciones = funcionesData ? JSON.parse(funcionesData) : this.defaultFunciones();
    this.compras = comprasData ? JSON.parse(comprasData) : [];
    this.compra = compraData ? JSON.parse(compraData) : {};
  }

  private defaultPeliculas() {
    return [
      { 
        id: 2, 
        titulo: 'EL ESPEJO DEL DIABLO', 
        director: 'Mike Flanagan', 
        genero: 'Terror', 
        duracion: '1:31', 
        clasificacion: 'R', 
        imagen: 'https://es.web.img3.acsta.net/medias/nmedia/18/86/91/41/19870073.jpg', 
        sinopsis: 'Sinopsis del Espejo...', 
        estado: true 
      },
      { 
        id: 3, 
        titulo: 'GODZILLA Y KONG: El nuevo Imperio', 
        director: 'Adam Wingard', 
        genero: 'Acción', 
        duracion: '1:55', 
        clasificacion: 'PG-13', 
        imagen: 'https://example.com/godzilla.jpg', 
        sinopsis: 'Sinopsis de Godzilla...', 
        estado: true 
      }
    ];
  }

  private defaultFunciones() {
    return [
      { 
        id: 2, 
        titulo: 'EL ESPEJO DEL DIABLO', 
        fecha: '2024-06-14', 
        hora: '19:00', 
        precio: 12.00, 
        capacidad: 40, 
        estado: false, 
        peliculaId: 2 
      },
      { 
        id: 3, 
        titulo: 'GODZILLA Y KONG: El nuevo Imperio', 
        fecha: '2024-06-15', 
        hora: '20:00', 
        precio: 10.00, 
        capacidad: 40, 
        estado: true, 
        peliculaId: 3 
      }
    ];
  }

  // Guardar datos en localStorage
  private saveData() {
    localStorage.setItem(this.peliculasKey, JSON.stringify(this.peliculas));
    localStorage.setItem(this.funcionesKey, JSON.stringify(this.funciones));
    localStorage.setItem(this.comprasKey, JSON.stringify(this.compras));
    localStorage.setItem(this.compraKey, JSON.stringify(this.compra));
  }

  // Métodos para Películas
 /*  addPelicula(pelicula: any) {
    pelicula.id = this.generateId(this.peliculas); 
    this.peliculas.push(pelicula);
    this.saveData();
  } */

  updatePelicula(id: number, pelicula: any) {
    const index = this.peliculas.findIndex(p => p.id === id);
    if (index !== -1) {
      this.peliculas[index] = { ...pelicula, id }; 
      this.saveData();
    }
  }

  deletePelicula(id: number) {
    this.peliculas = this.peliculas.filter(p => p.id !== id); 
    this.saveData();
  }

  getPeliculas() {
    return this.peliculas;
  }

  getPeliculaById(id: number) {
    return this.peliculas.find(pelicula => pelicula.id === id);
  }
  
  getPeliculaByIndex(index: number): any {
    return this.peliculas[index];
  }

  // Métodos para Funciones
  getFunciones() {
    return this.funciones;
  }

  addFuncion(funcion: any) {
    funcion.id = this.generateId(this.funciones); 
    this.funciones.push(funcion);
    this.saveData();
  }

  getFuncionById(id: number) {
    return this.funciones.find(funcion => funcion.id === id);
  }

  updateFuncion(id: number, funcion: any) {
    const index = this.funciones.findIndex(f => f.id === id);
    if (index !== -1) {
      this.funciones[index] = { ...funcion, id }; 
      this.saveData();
    }
  }

  deleteFuncion(id: number) {
    this.funciones = this.funciones.filter(f => f.id !== id); 
    this.saveData();
  }

  getFuncionesPorPelicula(peliculaId: number) {
    return this.funciones.filter(funcion => funcion.peliculaId === peliculaId); 
  }

  getPeliculasByFunciones(): any[] {
    const peliculaIds = this.funciones.map(funcion => funcion.peliculaId);
    return this.peliculas.filter(pelicula => peliculaIds.includes(pelicula.id));
  }

  // Métodos para Compras
  setCompra(compra: any) {
    const fechaHoraActual = new Date().toLocaleString();
    this.compra = {
        ...compra,
        fecha: compra.fecha,
        hora: compra.hora,
        fechaHoraCompra: fechaHoraActual
    };
  
    const pelicula = this.getPeliculaById(compra.peliculaId);
    if (pelicula) {
      this.compra.pelicula = pelicula;
    }
  
    this.compras.push(this.compra);
    this.saveData();
  }
  
  


  getCompras() {
    return this.compras;
  }

  getCompra() {
    return this.compra; // Asegúrate de que 'compra' tenga los datos que necesitas
  }
  

  // Método para generar un nuevo ID basado en el array existente
  private generateId(items: any[]): number {
    return items.length > 0 ? Math.max(...items.map(item => item.id)) + 1 : 1;
  }

  // Mejoras para el manejo de imágenes
  onImageError(event: Event) {
    const defaultImage = 'https://example.com/default-image.jpg'; 
    (event.target as HTMLImageElement).src = defaultImage;
  }

  // Método para obtener la película asociada a la compra
  getPeliculaDeCompra(compra: any): any {
    return this.peliculas.find(pelicula => pelicula.id === compra.peliculaId);
  }

  /**Conexion con el backend==================================*/

  private apiUrl = 'http://localhost:3000/api/v1/funcion';

  //Obtener todas las funciones
  getFuncioness(): Observable<Funcion[]> {
     return this.http.get<Funcion[]>(`${this.apiUrl}`); 
  }

  //Obtener funciones por ID
  getFuncionID(id: string): Observable<Funcion>{
    return this.http.get<Funcion>(`${this.apiUrl}/${id}`);
  }

  //Crear una funcion
  createFuncion(funcion: Funcion): Observable<Funcion>{
    return this.http.post<Funcion>(this.apiUrl, funcion);
  }
  
  //Actualizar una funcion
  updateFunciones(id: string, funcion: Funcion): Observable<Funcion>{
    const funcionData = { ...funcion}
    delete funcionData.__v;
    return this.http.patch<Funcion>(`${this.apiUrl}/${id}`, funcionData);

  }

  //Eliminar una funcion
  deleteFuncionn(id:string): Observable<void>{
    return this.http.delete<void>(`${this.apiUrl}/${id}`)
  }

  //Buscar Funciones
  searchFunciones(term: string): Observable<Funcion[]> {
    return this.http.get<Funcion[]>(`${this.apiUrl}?search=${term}`)
  }

  
  private apiUrlP = 'http://localhost:3000/api/v1/pelicula';

  //Obtener todas las pelicuas
  getPeliculass(): Observable<Pelicula[]>{
    return this.http.get<Pelicula[]>(`${this.apiUrlP}`);
  }

  //Crear pelicula
  createPelicula(pelicula: Pelicula): Observable<Pelicula>{
    return this.http.post<Pelicula>(this.apiUrlP, pelicula);
  }

  //Obtener por pelicula por ID
  getPeliculaID(id: string): Observable<Pelicula>{
    return this.http.get<Pelicula>(`${this.apiUrlP}/${id}`);
  }

  updatePeliculaa(id: string, pelicula: Pelicula): Observable<Pelicula>{
    const PeliculaData = { ...pelicula}
    delete PeliculaData.__v;
    return this.http.patch<Pelicula>(`${this.apiUrlP}/${id}`, PeliculaData);
  }
  
  deletePeliculaa(id: string): Observable<Pelicula>{
    return this.http.delete<Pelicula>(`${this.apiUrlP}/${id}`);
  }
}
