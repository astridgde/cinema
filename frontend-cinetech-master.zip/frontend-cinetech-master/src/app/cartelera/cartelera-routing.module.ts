import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CarteleraComponent } from './cartelera.component';

import { CarteleraSemanalComponent } from './components/cartelera-semanal/cartelera-semanal.component';
import { DetalleCompraComponent } from './detalle-compra/detalle-compra.component';
import { AdmCarteleraComponent } from './components/adm-cartelera/adm-cartelera.component';
import { AdmPeliculaComponent } from './components/adm-cartelera/adm-pelicula/adm-pelicula.component';
import { AdmFuncionComponent } from './components/adm-cartelera/adm-funcion/adm-funcion.component';
import { EditarFuncionComponent } from './components/adm-cartelera/adm-funcion/editar-funcion/editar-funcion.component';
import { EditarPeliculaComponent } from './components/adm-cartelera/adm-pelicula/editar-pelicula/editar-pelicula.component';
import { AgregarPeliculaComponent } from './components/adm-cartelera/adm-pelicula/agregar-pelicula/agregar-pelicula.component';
import { AgregarFuncionComponent } from './components/adm-cartelera/adm-funcion/agregar-funcion/agregar-funcion.component';
import { FormapagoComponent } from './pages/formapago/formapago.component';
import { BoletaComponent } from './pages/formapago/boleta/boleta.component';

const routes: Routes = [
  { path: '', component: CarteleraComponent },
  { path: 'adm-cartelera', component: AdmCarteleraComponent},
  { path: 'adm-pelicula', component: AdmPeliculaComponent },
  { path: 'adm-funcion', component: AdmFuncionComponent },
  { path: 'agregar-pelicula', component: AgregarPeliculaComponent },
  { path: 'agregar-funcion', component: AgregarFuncionComponent },
  { path: 'editar-funcion/:id', component: EditarFuncionComponent }, // Añade la ruta para editar función
  { path: 'editar-pelicula/:id', component: EditarPeliculaComponent },
  { path: 'cartelera-semanal', component: CarteleraSemanalComponent },
  { path: 'comprar', component: DetalleCompraComponent  },
  { path: 'formapago', component: FormapagoComponent  },
  { path: 'boleta', component: BoletaComponent  },
  
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class CarteleraRoutingModule { }
