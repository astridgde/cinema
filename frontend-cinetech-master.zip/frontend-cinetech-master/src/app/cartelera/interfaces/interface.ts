export interface Pelicula {
  _id?: string;
  titulo: string;
  imagen_pelicula: string;
  director_pelicula: string;
  genero: string;
  duracion: string;
  clasificacion: string;
  sinopsis?: string;
  estado: boolean;
  __v?: number;
}

  
export interface Funcion {
  _id?: string;
  fecha_funcion: string;
  hora_funcion: string;
  precio_entrada: number;
  capacidad_maxima: number;
  capacidad_disponible: number;
  id_pelicula?: string; //Para agregar funciones
  pelicula?: {//Para listar funciones
    titulo: string;
    imagen_pelicula: string;
    _id:string
  }
  estado: boolean;
  __v?: number
}

  
  export interface Compra {
  peliculaId: number;
  funcionId: number;
  cantidad: number;
  fechaHoraCompra: string;
  pelicula?: {
    titulo: string;
    precio: number;
    imagen: string;
  };

  }
  