import { Component, OnInit } from '@angular/core';
import { CarteleraService } from '../../services/Cartelera.service';
import { Router } from '@angular/router';
import { Pelicula,Funcion } from '../../interfaces/interface'; // Asegúrate de ajustar la ruta al archivo correcto

@Component({
  selector: 'app-cartelera-semanal',
  templateUrl: './cartelera-semanal.component.html',
  styleUrls: ['./cartelera-semanal.component.css']
})
export class CarteleraSemanalComponent implements OnInit {
  peliculas: Pelicula = {
    titulo: '',
    imagen_pelicula: '',
    director_pelicula: '',
    genero: '',
    duracion: '',
    clasificacion: '',
    estado: true
  }
  peliculass: Pelicula[] = [];
  funciones: Funcion[] = []; 
  _id: string = '';

  constructor(private peliculaService: CarteleraService, private router: Router) {}

  ngOnInit() {
   /*  // Obtener funciones y películas al inicializar
    this.funciones = this.peliculaService.getFunciones();
    this.peliculas = this.peliculaService.getPeliculas();
    
    // Para depuración
    console.log('Funciones:', this.funciones);
    console.log('Películas:', this.peliculas); */
    this.listarFunciones();
    this.listarPeliculas();
  }

  listarFunciones() {
    this.peliculaService.getFuncioness().subscribe(
      (data) => {
        this.funciones = data;
        console.log('Funciones obtenidas', data);
      },
      (error) => {
        console.error('Error al obtener funciones', error);
      }
    )
  }

  listarPeliculas() {
  this.peliculaService.getPeliculass().subscribe(
    (data) => {
      this.peliculass = data;
      console.log('Películas obtenidas', data); // Verifica las URLs de las imágenes
    },
    (error) => {
      console.error('Error al obtener películas', error);
    }
  );
}


  // Método para realizar la compra de una película
  comprar(funcion: Funcion) {
    // Guardar información de la compra en el servicio
    this.peliculaService.setCompra({
      pelicula: funcion.pelicula,
      fecha: funcion.fecha_funcion,
      hora: funcion.hora_funcion,
      precio: funcion.precio_entrada,
      cantidad: 1 // Suponiendo que la cantidad inicial es 1
    });
  
    // Redirigir a la página de detalle de compra
    this.router.navigate(['/cartelera/comprar']);
  }
  

  // Obtener la película por su ID
  /* getPeliculaById(_id: any): Pelicula | undefined {
    const pelicula = this.peliculass.find(pelicula => pelicula._id === _id);
    console.log('Película encontrada:', pelicula); // Para depuración
    return pelicula;
  } */
  getPeliculaById() {
    this.peliculaService.getPeliculaID(this._id).subscribe(
      (data) => {
        this.peliculas = data;
        console.log('Pelicula Obtenida con exito', data);
      },
      (error) => {
        console.error('Error al obtener pelicula');
      }
    )
  }
  

  // Manejo de errores de imagen
  onImageError(event: Event) {
    const imgElement = event.target as HTMLImageElement;
    imgElement.src = 'https://example.com/default-image.jpg'; // Imagen predeterminada
  }
}
