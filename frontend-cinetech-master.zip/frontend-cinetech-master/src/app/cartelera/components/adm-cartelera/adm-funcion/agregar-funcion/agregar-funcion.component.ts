import { Component, OnInit } from '@angular/core';
import { CarteleraService } from '../../../../services/Cartelera.service';
import { Router } from '@angular/router';
import { Funcion, Pelicula } from '../../../../interfaces/interface';

@Component({
  selector: 'app-agregar-funcion',
  templateUrl: './agregar-funcion.component.html',
  styleUrl: './agregar-funcion.component.css'
})
export class AgregarFuncionComponent implements OnInit {
    peliculas: Pelicula[] = [];
    funcion: Funcion = {
      fecha_funcion: '',
      hora_funcion: '',
      precio_entrada: 0,
      capacidad_maxima: 0,
      capacidad_disponible: 0,
      id_pelicula: '',
      estado: true
    }

    constructor(private carteleraService: CarteleraService, private router: Router) { }

    ngOnInit() {
      this.ListarPeliculas();
    }

    cancelar() {
      this.router.navigate(['/cartelera/adm-funcion']);
    }

    agregarFuncion(){
      this.carteleraService.createFuncion(this.funcion).subscribe(
        (response) =>{
          console.log('Funcion registrada', response);
          alert('Persona refistrada exitosamente');
          this.router.navigate(['/cartelera/adm-funcion']);
        },
        (error) => {
          console.error('Error al registrar funcion: ', error);
          alert(`Error: ${error.error.message || 'No se pudo registrar'}`);
        }
      )
    }


    ListarPeliculas(){
      this.carteleraService.getPeliculass().subscribe(
        (data) => {
          this.peliculas = data;
          console.log('Peliculas obtenidas con exito');
        },
        (error) => {
          console.error('Error al listar peliculas', error);
        }
      )
    }
}
