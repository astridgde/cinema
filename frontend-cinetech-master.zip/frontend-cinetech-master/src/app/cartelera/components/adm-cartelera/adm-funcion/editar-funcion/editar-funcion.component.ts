import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { CarteleraService } from '../../../../services/Cartelera.service';
import { Funcion, Pelicula } from '../../../../interfaces/interface';

@Component({
  selector: 'app-editar-funcion',
  templateUrl: './editar-funcion.component.html',
  styleUrls: ['./editar-funcion.component.css']
})
export class EditarFuncionComponent implements OnInit {
  peliculas: Pelicula[] = [];
  _id: string = '';

  funcion: Funcion = {
    fecha_funcion: '',
    hora_funcion: '',
    precio_entrada: 0,
    capacidad_maxima: 0,
    capacidad_disponible: 0,
    id_pelicula: '',
    estado: true
  };

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private carteleraService: CarteleraService
  ) { }

  ngOnInit(): void {
    this._id = this.route.snapshot.paramMap.get('id') || '';
    this.ListarPeliculas();

    this.carteleraService.getFuncionID(this._id).subscribe(
      (data) => {
        // Convertir la fecha
        data.fecha_funcion = new Date(data.fecha_funcion).toISOString().split('T')[0];
        this.funcion = data;
        this.funcion.id_pelicula = this.funcion.pelicula?._id || '';
      },
      (error) => { 
        console.error('Error al cargar la función:', error); 
      }
    );
  }

  actualizarFunciones() {
    if (this.funcion._id) {
      // Asegúrate de que id_pelicula no está vacío antes de enviar los datos
      if (!this.funcion.id_pelicula) {
        alert('Debe seleccionar una película.');
        return;
      }

      // Preparar los datos para actualizar sin la propiedad pelicula
      const { pelicula, _id, ...funcionData } = this.funcion;

      this.carteleraService.updateFunciones(this.funcion._id, funcionData).subscribe(
        (respuesta) => {
          console.log('Función actualizada', respuesta);
          alert('Función actualizada exitosamente');
          this.router.navigate(['/cartelera/adm-funcion']);
        },
        (error) => {
          console.error('Error al actualizar una función:', error);
          alert(`Error: ${error.error.message || 'No se pudo actualizar'}`);
        }
      );
    }
  }

  cancelar() {
    this.router.navigate(['/cartelera/adm-funcion']);
  }

  ListarPeliculas() {
    this.carteleraService.getPeliculass().subscribe(
      (data) => {
        this.peliculas = data;
        console.log('Películas obtenidas con éxito');
      },
      (error) => {
        console.error('Error al listar películas', error);
      }
    );
  }
}
