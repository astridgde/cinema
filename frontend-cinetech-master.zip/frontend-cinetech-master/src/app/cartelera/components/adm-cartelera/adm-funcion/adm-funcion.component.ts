import { Component, OnInit } from '@angular/core';
import { CarteleraService } from '../../../services/Cartelera.service';
import { Router } from '@angular/router';
import { Funcion } from '../../../interfaces/interface';

@Component({
  selector: 'app-adm-funcion',
  templateUrl: './adm-funcion.component.html',
  styleUrl: './adm-funcion.component.css'
})
export class AdmFuncionComponent implements OnInit {
    searchText: string = '';
    showFilter: boolean = false;
    selectedDateFrom: string = '';
    selectedDateTo: string = '';
    allFunciones: Funcion[] = []; // Para almacenar todas las funciones

    constructor(private carteleraService: CarteleraService, private router: Router) { }

    ngOnInit(): void {
      this.listarFunciones();
    }

    navigateTo(route: string) {
      if (route === 'agregar-funcion') {
        this.router.navigate(['/cartelera/agregar-funcion']);
      } else if (route === 'adm-pelicula') {
        this.router.navigate(['/cartelera/adm-pelicula']);
      } else if (route === 'adm-funcion') {
        this.router.navigate(['/cartelera/adm-funcion']);
      }
    }
    

    agregarFuncion() {
      this.navigateTo('agregar-funcion');
    }

    editarFuncion(_id: string) {
      this.router.navigate(['/cartelera/editar-funcion', _id]);
    }

    eliminarFuncion(_id: string) {
      if(confirm('Estas seguro que deseas eliminar esta funcion')) {
        this.carteleraService.deleteFuncionn(_id).subscribe(
          () => {
            this.funcioness = this.funcioness.filter(funcion => funcion._id !== _id);
            this.listarFunciones();
            console.log('Funcion eliminada con exito');
          },
          (error) => {
            console.error('Error al eliminar funcion', error);
          }
        )
      }
    }
    

    buscarFunciones() {
      if(this.searchText.trim()){
        this.carteleraService.searchFunciones(this.searchText).subscribe(
          (data) => {
            if(data.length > 0){
              this.funcioness = data;
            }else {
              this.funcioness = this.allFunciones;
            }
            console.log('Resultados de busqueda', data);
          },
          (error) => {
            console.error('Error al buscar funcion', error);
            this.funcioness = this.allFunciones;
          }
        );
      } else {
        this.listarFunciones();
      }
    }


    //LISTAR FUNCIONES DESDE LA BASE DE DATOS NO RELACIONAL MONGODB

    funcioness: Funcion[] = []
    listarFunciones(){
      this.carteleraService.getFuncioness().subscribe(
        (data) => {
          this.funcioness = data;
          console.log('Funciones Obtenidas con exito', data);
        },
        (error) => {
          console.error('Error al listar Funciones', error);
        }
      )
    }
}
