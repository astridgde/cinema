import { Component, OnInit } from '@angular/core';
import { CarteleraService } from '../../../services/Cartelera.service';
import { Router } from '@angular/router';
import { Pelicula } from '../../../interfaces/interface';
import * as bootstrap from 'bootstrap';


@Component({
  selector: 'app-adm-pelicula',
  templateUrl: './adm-pelicula.component.html',
  styleUrl: './adm-pelicula.component.css'
})
export class AdmPeliculaComponent implements OnInit {
  peliculass: Pelicula[] = [];
  selectedMovie: Pelicula | null = null; // Película seleccionada para mostrar en el modal

  constructor(private carteleraService: CarteleraService, private router: Router) { }

  ngOnInit(): void {
    this.listarPeliculas();
  }

  navigateTo(page: string) {
    if (page === 'agregar-pelicula') {
      this.router.navigate(['/cartelera/agregar-pelicula']);
    } else if (page === '/cartelera/adm-pelicula') {
      this.router.navigate(['/cartelera/adm-pelicula']);
    } else if (page === 'adm-funcion') {
      this.router.navigate(['/cartelera/adm-funcion']);
    }
  }

  //Listar todas las peliculas de las BD
  listarPeliculas() {
    this.carteleraService.getPeliculass().subscribe(
      (data) => {
        this.peliculass = data;
        console.log('Peliculas obtenidas con exito', data);
      },
      (error) => {
        console.error('Error al obtener peliculas', error);
      }
    )
  }

  //Ir al formulario de editar pelicula
  editarPelicula(_id: string) {
    this.router.navigate(['/cartelera/editar-pelicula', _id]);
  }

  //Metodo para eliminar una pelicula
  eliminarPelicula(_id: string) {
    if (confirm('Estas seguro de eliminar esta pelicula')) {
      this.carteleraService.deletePeliculaa(_id).subscribe(
        () => {
          this.peliculass = this.peliculass.filter(pelicula => pelicula._id !== _id);
          this.listarPeliculas();
          console.log('Funcion eliminada con exito');
        },
        (error) => {
          console.error('Error al eliminar pelicula', error);
        }
      )
    }
  }
  
  //Metodo de abrir una ventana emergente, para abrir la sinopsis de la pelicula
  openDetails(pelicula: Pelicula): void {
    this.selectedMovie = pelicula;
    const modalElement = document.getElementById('detailsModal');
    if (modalElement) {
      const modal = new bootstrap.Modal(modalElement);
      modal.show();
    }
  }
}
