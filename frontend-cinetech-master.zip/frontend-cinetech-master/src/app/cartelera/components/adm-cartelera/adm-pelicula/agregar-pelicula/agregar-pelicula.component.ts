import { Component } from '@angular/core';
import { CarteleraService } from '../../../../services/Cartelera.service';
import { Router } from '@angular/router';
import { Pelicula } from '../../../../interfaces/interface';

@Component({
  selector: 'app-agregar-pelicula',
  templateUrl: './agregar-pelicula.component.html',
  styleUrl: './agregar-pelicula.component.css'
})
export class AgregarPeliculaComponent {
    
  pelicula: Pelicula = {
    titulo: '',
    imagen_pelicula: '',
    director_pelicula: '',
    genero: '',
    duracion: '',
    clasificacion: '',
    sinopsis: '',
    estado: true
  }

    constructor(private carteleraService: CarteleraService, private router: Router) {}


    agregarPelicula() {
      this.carteleraService.createPelicula(this.pelicula).subscribe(
        (response) => {
          console.log('Película creada:', response);
          alert('Película creada exitosamente');
          this.router.navigate(['/cartelera/adm-pelicula']);
        },
        (error) => {
          if (error.status === 201) { // Código de éxito en algunos casos
            alert('Película creada con éxito');
            this.router.navigate(['/cartelera/adm-pelicula']);
          } else {
            console.error('Error desconocido:', error);
            alert(`Error: ${error.message || 'Error desconocido'}`);
          }
        }
      );
    }

    cancelar() {
      this.router.navigate(['/cartelera/adm-pelicula']);
    }
    
    
}
