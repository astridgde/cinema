import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { CarteleraService } from '../../../../services/Cartelera.service';
import { Pelicula, Funcion } from '../../../../interfaces/interface';

@Component({
  selector: 'app-editar-pelicula',
  templateUrl: './editar-pelicula.component.html',
  styleUrls: ['./editar-pelicula.component.css']
})
export class EditarPeliculaComponent implements OnInit {

  _id: string = '';

  pelicula : Pelicula = {
    titulo: '',
    imagen_pelicula: '',
    director_pelicula: '',
    genero: '',
    duracion: '',
    clasificacion: '',
    sinopsis: '',
    estado: true
  };

    constructor(
      private route: ActivatedRoute,
      private router: Router,
      private carteleraService: CarteleraService
    ) { }

    ngOnInit(): void{
      this._id = this.route.snapshot.paramMap.get('id') || '';

      this.getPeliculasID();
    }

    getPeliculasID(): void{
      this.carteleraService.getPeliculaID(this._id).subscribe(
        (data) => {
          this.pelicula = data;
        },
        (error) => {
          console.error('Error al Obtener pelicula', error)
        }
      )
    }

    actualizarPelicula(){
      const { _id, ...peliculaData } = this.pelicula;

      this.carteleraService.updatePeliculaa(this._id, peliculaData).subscribe(
        (data) => {
          console.log('Pelicula actualizada', data);
          alert('Pelicula actualizada exitosamente');
          this.router.navigate(['/cartelera/adm-pelicula']);
        },
        (error) => {
          console.error('Error al actualizar pelicula', error);
          alert(`Error: ${error.error.message || 'No se pudo actualizar'}`);
        }
      )
    }

    cancelar() {
      this.router.navigate(['/cartelera/adm-pelicula']);
    }
}
