import { Component } from '@angular/core';

@Component({
  selector: 'app-adm-cartelera',
  templateUrl: './adm-cartelera.component.html',
  styleUrl: './adm-cartelera.component.css'
})
export class AdmCarteleraComponent {

}