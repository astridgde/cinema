export interface Trabajador {
    nombres?: string;
    apellidos?: string;
    tipoDoc?: string;
    numeroDoc?: string;
    email?: string;
    nombreUsuario?: string;
    contrasena?: string;
    numCelu?: string;
    fechaNan?: string;
    rol?: string;
  }