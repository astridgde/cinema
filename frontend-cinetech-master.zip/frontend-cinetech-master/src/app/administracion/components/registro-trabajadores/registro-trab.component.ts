import { Component } from '@angular/core';
import { AdministracionService } from '../../services/Administracion.service';
import { Router } from '@angular/router';
import { User } from '../../../autenticacion/interfaces/user.interface';

@Component({
  selector: 'app-registro-trabajadores',
  templateUrl: './registro-trab.component.html',
  styleUrls: ['./registro-trab.component.css']
})
export class RegistroTrabComponent {
  trabajador: User = {
    firstName: '',
    lastName: '',
    documentType: '',
    documentNumber: '',
    email: '',
    username: '',
    password: '',
    phoneNumber: '',
    birthDate: '',
    rol: 'trabajador',
  };

  showPassword: boolean = false; // Controla la visibilidad de la contraseña

  constructor(private administracionService: AdministracionService, private router: Router) {}

  registerTrab() {
    // Llamada al servicio para registrar al trabajador
    this.administracionService.newTrabajador(this.trabajador);

    console.log('Registro completo');
    this.router.navigate(['/autenticacion/aut/inicio-sesion']);
  }

  // Método para alternar la visibilidad de la contraseña
  togglePasswordVisibility() {
    this.showPassword = !this.showPassword;
  }
}
