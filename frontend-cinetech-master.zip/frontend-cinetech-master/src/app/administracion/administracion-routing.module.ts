import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AdministracionComponent } from './administracion.component';
import { RegistroTrabComponent } from './components/registro-trabajadores/registro-trab.component';


const routes: Routes = [
  { path: '', component: AdministracionComponent },
  { path: 'registro-trab', component: RegistroTrabComponent },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AdministracionRoutingModule { }
