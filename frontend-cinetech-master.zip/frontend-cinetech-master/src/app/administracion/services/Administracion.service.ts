import { Injectable } from '@angular/core';
import { Trabajador } from '../interfaces/trabajador.interface';
import { User } from '../../autenticacion/interfaces/user.interface';
import { AutenticacionService } from '../../autenticacion/services/Autenticacion.service';

@Injectable({
  providedIn: 'root'
})
export class AdministracionService {

  constructor(private AutenticacionService: AutenticacionService) { }

  newTrabajador(user:User){
    this.AutenticacionService.registerUser(user)
  }


}
