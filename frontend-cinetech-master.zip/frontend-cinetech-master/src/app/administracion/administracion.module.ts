import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AdministracionRoutingModule } from './administracion-routing.module';
import { AdministracionComponent } from './administracion.component';
import { RegistroTrabComponent } from './components/registro-trabajadores/registro-trab.component';
import { FormsModule } from '@angular/forms';


@NgModule({
  declarations: [
    AdministracionComponent,
    RegistroTrabComponent
  ],
  imports: [
    CommonModule,
    AdministracionRoutingModule,
    FormsModule
  ],
  exports: [
    AdministracionComponent,
    RegistroTrabComponent
  ]
})
export class AdministracionModule { }
