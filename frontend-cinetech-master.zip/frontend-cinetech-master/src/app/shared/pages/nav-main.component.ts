import { Component, OnInit } from '@angular/core';
import { User } from '../../autenticacion/interfaces/user.interface';
import { AutenticacionService } from '../../autenticacion/services/Autenticacion.service';
import { ChangeDetectorRef } from '@angular/core';

@Component({
  selector: 'app-nav-main',
  templateUrl: './nav-main.component.html'
})
export class NavMainComponent implements OnInit {
  user?: User;
  
  constructor(
    private autenticacionService: AutenticacionService,
    private cdRef: ChangeDetectorRef
  ) {}

  ngOnInit(): void {
    this.autenticacionService.userLogin$.subscribe(user => {
      this.user = user;
      this.cdRef.detectChanges();
    });
  }
}
