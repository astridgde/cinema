import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { SharedRoutingModule } from './shared-routing.module';
import { SharedComponent } from './shared.component';
import { NavComponent } from './components/nav/nav.component';
import { RouterModule } from '@angular/router';
import { NavTrabajadorComponent } from './components/nav-trabajador/nav-trabajador.component';
import { NavMainComponent } from './pages/nav-main.component';


@NgModule({
  declarations: [
    SharedComponent,
    NavComponent,
    NavTrabajadorComponent,
    NavMainComponent
  ],
  imports: [
    CommonModule,
    SharedRoutingModule,
    RouterModule
  ],
  exports: [
    SharedComponent,
    NavComponent,
    NavTrabajadorComponent,
    NavMainComponent
  ]
})
export class SharedModule { }
