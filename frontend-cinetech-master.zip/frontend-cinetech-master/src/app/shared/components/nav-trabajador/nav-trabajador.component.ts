import { Component } from '@angular/core';
import { User } from '../../../autenticacion/interfaces/user.interface';
import { AutenticacionService } from '../../../autenticacion/services/Autenticacion.service';

@Component({
  selector: 'app-nav-trabajador',
  templateUrl: './nav-trabajador.component.html',
  styleUrl: './nav-trabajador.component.css'
})
export class NavTrabajadorComponent {

  user: User | undefined; // Asegúrate de que esta propiedad esté declarada correctamente

  constructor(private autenticacionService: AutenticacionService) {}

  ngOnInit(): void {
    // Suscríbete al observable para obtener el usuario logueado
    this.autenticacionService.userLogin$.subscribe(user => {
      this.user = user; // Asigna el valor del usuario
    });
  }

  CerrarSesion(): void {
    this.autenticacionService.logoutUser(); // Llama al servicio para cerrar sesión
  }
}
