import { Component, OnInit } from '@angular/core';
import { AutenticacionService } from '../../../autenticacion/services/Autenticacion.service';// Ajusta la ruta según tu estructura
import { Users } from '../../../autenticacion/interfaces/user.interface';// Ajusta la ruta según tu estructura

@Component({
  selector: 'app-nav',
  templateUrl: './nav.component.html',
  styleUrls: ['./nav.component.css'] // Asegúrate de que el nombre sea plural
})
export class NavComponent implements OnInit {
  user: Users | undefined; // Asegúrate de que esta propiedad esté declarada correctamente
  nombre_usuario: string = '';
  password: string = '';

  constructor(private autenticacionService: AutenticacionService) {}

  ngOnInit(): void {
    /* // Suscríbete al observable para obtener el usuario logueado
    this.autenticacionService.userLogin$.subscribe(user => {
      this.user = user; // Asigna el valor del usuario
    }); */
    this.autenticacionService.login(this.nombre_usuario, this.password).subscribe(
      (data) => {
        console.log('Datos traidos', data);
      },
      (error) => {
        console.error('Error al obtener nombre de usuario', error)
      }
    )
  }

  CerrarSesion(): void {
    this.autenticacionService.logoutUser(); // Llama al servicio para cerrar sesión
  }
}

