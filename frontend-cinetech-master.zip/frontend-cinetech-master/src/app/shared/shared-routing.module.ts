import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { SharedComponent } from './shared.component';
import { NavComponent } from './components/nav/nav.component';
import { NavTrabajadorComponent } from './components/nav-trabajador/nav-trabajador.component';

const routes: Routes = [{ path: '', component: SharedComponent }
  
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class SharedRoutingModule { }
