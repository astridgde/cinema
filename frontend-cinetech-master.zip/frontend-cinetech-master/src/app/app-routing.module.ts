import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  { path: 'administracion', loadChildren: () => import('./administracion/administracion.module').then(m => m.AdministracionModule) },
  { path: 'autenticacion', loadChildren: () => import('./autenticacion/autenticacion.module').then(m => m.AutenticacionModule) },
  { path: 'cartelera', loadChildren: () => import('./cartelera/cartelera.module').then(m => m.CarteleraModule) },
  { path: 'facturacion', loadChildren: () => import('./facturacion/facturacion.module').then(m => m.FacturacionModule) },
  { path: 'home', loadChildren: () => import('./home/home.module').then(m => m.HomeModule) },
  { path: 'shared', loadChildren: () => import('./shared/shared.module').then(m => m.SharedModule) },
  { path: '', redirectTo: '/home', pathMatch: 'full' },
  

  { path: '**', redirectTo: '/home' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
